# STRATVO / ROI-Labs — ICP Extractor

Extrator robusto para **varrer até 50 fontes** de vagas no Brasil, **somente por vias seguras (API/feeds e páginas públicas permitidas)**, coletando **descrição da vaga** e detectando **tecnologias/sistemas** (TOTVS Protheus, Datasul, RM, Fluig, SAP etc.) para cálculo de **ICP**.

> ✅ Legal-compliance: prioriza APIs/feeds e páginas públicas indexadas. Itens marcados como `enabled: false` não são varridos por padrão.

## Requisitos
- Node 18+
- `npm i`
- Configurar chaves em `.env` (se tiver): `ADZUNA_APP_ID`, `ADZUNA_APP_KEY`, `JOOBLE_API_KEY`

## Uso básico
```bash
npm run run -- --q="Analista" --loc="São Paulo" --limit=200
```

## Saída
Gera `outputs/results.jsonl` com itens:
```json
{
  "source": "Adzuna",
  "url": "...",
  "empresa": "Acme",
  "titulo": "Analista de Sistemas",
  "descricao": "texto...",
  "tecnologias": [{"nome":"TOTVS Protheus","confianca":0.78}],
  "publicado_em": "2025-10-23",
  "coletado_em": "2025-10-30T23:59:59Z"
}
```

## Fontes
Veja `src/config/sources.js`. Por padrão, só as com `mode: "api"` vêm **enabled: true**. 
Para expandir gradualmente, habilite `"public"` **apenas** onde a página é aberta/permitida pelo robots.txt.

## Integração Lovable.dev
- O projeto é modular (adapters por fonte) e a função de extração de tecnologias é independente (`extract/extractTech.js`).
- Integre este projeto como sub-processo (CLI) ou migre os módulos para o back-end do Lovable.
