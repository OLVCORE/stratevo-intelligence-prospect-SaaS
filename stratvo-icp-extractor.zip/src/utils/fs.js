import fs from 'fs/promises';

export async function ensureDir(p) {
  await fs.mkdir(p, { recursive: true });
}

export async function delay(ms) {
  return new Promise(r => setTimeout(r, ms));
}
