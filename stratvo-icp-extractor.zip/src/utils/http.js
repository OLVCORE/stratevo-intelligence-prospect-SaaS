import axios from 'axios';
import Bottleneck from 'bottleneck';

const limiter = new Bottleneck({
  minTime: 300, // ~3 req/seg por origem
  maxConcurrent: 3
});

export const http = axios.create({
  timeout: 20000,
  headers: {
    'User-Agent': 'STRATVO-ICP-Extractor/1.0 (+compliance; contact: ops@olvinternacional.com.br)'
  },
  validateStatus: (s) => s >= 200 && s < 400
});

export function get(url, cfg = {}) {
  return limiter.schedule(() => http.get(url, cfg));
}

export function post(url, data, cfg = {}) {
  return limiter.schedule(() => http.post(url, data, cfg));
}
