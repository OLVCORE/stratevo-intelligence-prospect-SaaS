import 'dotenv/config';
import { runPipeline } from './pipeline/run.js';

// Entrypoint simplificado
runPipeline().catch((err) => {
  console.error('[FATAL]', err);
  process.exit(1);
});
