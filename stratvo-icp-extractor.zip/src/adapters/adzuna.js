import { get } from '../utils/http.js';

/**
 * Adzuna API (necessita ADZUNA_APP_ID e ADZUNA_APP_KEY)
 * Doc: https://developer.adzuna.com/overview
 */
export async function adzunaAdapter({ q, loc, limit, source }) {
  const app_id = process.env.ADZUNA_APP_ID;
  const app_key = process.env.ADZUNA_APP_KEY;
  if (!app_id || !app_key) { 
    console.warn('[Adzuna] missing credentials, skipping'); 
    return []; 
  }
  const results = [];
  const pageSize = 50;
  for (let page = 1; results.length < limit && page <= 5; page++) {
    const url = `https://api.adzuna.com/v1/api/jobs/br/search/${page}?app_id=${app_id}&app_key=${app_key}&results_per_page=${pageSize}&what=${encodeURIComponent(q)}&where=${encodeURIComponent(loc)}`;
    const { data } = await get(url);
    for (const j of (data.results || [])) {
      results.push({
        url: j.redirect_url,
        empresa: j.company?.display_name || null,
        titulo: j.title,
        descricao: j.description || '',
        publicado_em: j.created
      });
      if (results.length >= limit) break;
    }
  }
  return results;
}
