import { get } from '../utils/http.js';
import cheerio from 'cheerio';

/**
 * Generic HTML adapter: só use para páginas explicitamente públicas e permitidas.
 * Configurar em sources.json com "selectors" de CSS.
 * Exemplo de selectors:
 * {
 *   "item": ".job-card",
 *   "title": ".job-title",
 *   "company": ".company",
 *   "link": "a.job-link",
 *   "snippet": ".job-snippet"
 * }
 */
export async function genericHtmlAdapter({ q, loc, limit, source }) {
  const { baseUrl, selectors } = source;
  if (!baseUrl || !selectors) { console.warn('[GenericHTML] missing selectors/baseUrl'); return []; }
  const url = baseUrl.replace('{q}', encodeURIComponent(q)).replace('{loc}', encodeURIComponent(loc));
  const { data } = await get(url, { headers: { 'Accept': 'text/html' } });
  const $ = cheerio.load(data);
  const out = [];
  $(selectors.item).each((_, el) => {
    const $el = $(el);
    const titulo = selectors.title ? $el.find(selectors.title).text().trim() : null;
    const empresa = selectors.company ? $el.find(selectors.company).text().trim() : null;
    const href = selectors.link ? $el.find(selectors.link).attr('href') : null;
    const descricao = selectors.snippet ? $el.find(selectors.snippet).text().trim() : '';
    if (titulo && href) {
      const link = href.startsWith('http') ? href : new URL(href, url).toString();
      out.push({ url: link, empresa, titulo, descricao });
    }
  });
  return out.slice(0, limit);
}
