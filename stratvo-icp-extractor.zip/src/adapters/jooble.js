import { post } from '../utils/http.js';

/**
 * Jooble API - requer JOOBLE_API_KEY
 * Doc: https://jooble.org/api/about
 */
export async function joobleAdapter({ q, loc, limit, source }) {
  const key = process.env.JOOBLE_API_KEY;
  if (!key) { console.warn('[Jooble] missing JOOBLE_API_KEY, skipping'); return []; }
  const body = { keywords: q, location: loc, page: 1 };
  const results = [];
  while (results.length < limit && body.page <= 5) {
    const { data } = await post(`https://jooble.org/api/${key}`, body, { headers: { 'Content-Type': 'application/json' } });
    for (const j of (data.jobs || [])) {
      results.push({
        url: j.link,
        empresa: j.company || null,
        titulo: j.title,
        descricao: j.snippet || '',
        publicado_em: j.updated || j.date
      });
      if (results.length >= limit) break;
    }
    body.page += 1;
  }
  return results;
}
