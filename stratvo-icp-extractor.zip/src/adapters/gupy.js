export async function gupyAdapter({ q, loc, limit, source }) {
  console.warn('[Gupy] Adapter público é dependente de HTML dinâmico; habilite quando houver endpoint estável.');
  return [];
}
