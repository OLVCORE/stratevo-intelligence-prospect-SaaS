export const sources = [
  {
    "name": "Adzuna",
    "mode": "api",
    "adapter": "adzuna",
    "enabled": true
  },
  {
    "name": "Jooble",
    "mode": "api",
    "adapter": "jooble",
    "enabled": true
  },
  {
    "name": "LinkedIn",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Indeed",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Infojobs",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Vagas.com",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Catho",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Gupy",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Glassdoor",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Solides",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "BNE",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Trabalha Brasil",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Emprega Brasil (SINE)",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Jooble Web",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Adzuna Web",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Talent.com",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Jora",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Jobrapido",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Jobsora",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "JobisJob",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Jobatus",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Empregos.com.br",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Manager",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Curriculum",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Emprego.net",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Recruta Simples",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Emprego Ligado",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Jobbol",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Elancers",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Abler Jobs",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "JobConvo",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Trampos.co",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "CIEE",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Nube",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "IEL Estágio",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "99jobs",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Trabalhando.com.br",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Remotar",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "GeekHunter",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "EmpregosTI",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "BuscoJobs",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Vagas PCD",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Michael Page",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Page Personnel",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Robert Half",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Randstad",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "ManpowerGroup",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Adecco",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Hays",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Luandre",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Gi Group",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  },
  {
    "name": "Kelly Services",
    "mode": "public",
    "adapter": "genericHtml",
    "enabled": false
  }
];