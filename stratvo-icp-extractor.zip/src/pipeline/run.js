import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { sources } from '../config/sources.js';
import { adzunaAdapter } from '../adapters/adzuna.js';
import { joobleAdapter } from '../adapters/jooble.js';
import { gupyAdapter } from '../adapters/gupy.js';
import { genericHtmlAdapter } from '../adapters/genericHtml.js';
import { extractTech } from '../extract/extractTech.js';
import { ensureDir } from '../utils/fs.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function parseArgs() {
  const args = process.argv.slice(2);
  const out = { q: 'administrativo', loc: 'Brasil', limit: 100 };
  for (let i = 0; i < args.length; i++) {
    const [k, v] = args[i].split('=');
    if (k === '--q') out.q = v || out.q;
    if (k === '--loc') out.loc = v || out.loc;
    if (k === '--limit') out.limit = Number(v || out.limit);
  }
  return out;
}

export async function runPipeline() {
  const { q, loc, limit } = parseArgs();
  console.log(`[RUN] query="%s" loc="%s" limit=%d`, q, loc, limit);
  await ensureDir(path.join(__dirname, '../../outputs'));
  const outFile = path.join(__dirname, '../../outputs/results.jsonl');
  const outStream = fs.createWriteStream(outFile, { flags: 'a' });

  const adapters = {
    'adzuna': adzunaAdapter,
    'jooble': joobleAdapter,
    'gupy': gupyAdapter,
    'genericHtml': genericHtmlAdapter
  };

  const enabled = sources.filter(s => s.enabled);
  console.log(`[SOURCES] total=%d enabled=%d`, sources.length, enabled.length);

  let count = 0;
  for (const s of enabled) {
    const adapter = adapters[s.adapter];
    if (!adapter) { console.warn('[SKIP] no adapter for', s.name); continue; }
    console.log(`[SRC] ${s.name} -> ${s.adapter}`);
    try {
      const items = await adapter({ q, loc, limit, source: s });
      for (const it of items) {
        // Extração de tecnologias
        const tecnologias = extractTech(it.descricao || '');
        const rec = {
          source: s.name,
          url: it.url,
          empresa: it.empresa,
          titulo: it.titulo,
          descricao: it.descricao,
          publicado_em: it.publicado_em || null,
          coletado_em: new Date().toISOString(),
          tecnologias
        };
        outStream.write(JSON.stringify(rec, null, 0) + '\n');
        count++;
      }
    } catch (err) {
      console.error('[ERR]', s.name, err.message);
    }
  }

  outStream.end();
  console.log(`[DONE] registros gravados: ${count} -> outputs/results.jsonl`);
}
