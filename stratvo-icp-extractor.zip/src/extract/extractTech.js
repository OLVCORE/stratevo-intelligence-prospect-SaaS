import { TECH_DICT } from './techDictionary.js';

function escapeRegExp(s){ return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function occurrences(haystack, needle) {
  const re = new RegExp(`\\b${escapeRegExp(needle.trim())}\\b`, 'g');
  const m = haystack.match(re);
  return m ? m.length : 0;
}

export function extractTech(text) {
  const t = (text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, ' ')
    .replace(/\s+/g, ' ');
  const out = [];
  for (const [name, kws] of Object.entries(TECH_DICT)) {
    let hits = 0;
    for (const kw of kws) {
      hits += occurrences(t, kw.toLowerCase());
    }
    if (hits > 0) {
      const conf = Math.min(1, 0.45 + 0.15 * hits);
      out.push({ nome: name, ocorrencias: hits, confianca: Number(conf.toFixed(2)) });
    }
  }
  return out.sort((a, b) => b.confianca - a.confianca);
}
